# Stage 41 — High-Risk Expeditions

## Stage 41.1 — Lapidação das expedições

### Locais reconstruídos
Cada expedição ganhou geometria própria e uma entrada num vão real do mapa. As escadas da versão anterior atravessavam o Motel Pine Rest e a Oficina Westline e chegavam a 40 blocos de altura.

- **Abrigo do Xerife (1/5)** — mudou para a Estrada 17, entre a Lavoura Harlow e os trailers: um porão raso com armaria (sacos de areia, rack), área de descanso iluminada por lanterna (beliche, mural, rádio) e sala de evidências atrás de uma grade. Um túnel de fuga sai no campo da lavoura.
- **Quarentena Harlow (2/5)** — fica sob o pátio cercado do Hospital Regional Harlow. Tem triagem, posto de segurança com sacos de areia, ala de isolamento em concreto de contenção e só luzes de emergência. Uma escada liga o posto ao porão do hospital.
- **Bunker Greenwater (3/5)** — fica no campo depois da Horta Comunitária. São cinco salas: eclusa, sala do gerador, dormitório, despensa com canteiro abandonado e cofre. Uma escotilha de emergência só abre por dentro.
- **Arsenal do Condado (4/5)** — fica sob o pátio ferroviário de Westline, em dois andares: um corredor de serviço estreito e um salão principal com anteparos, que se encontram diante do depósito. Quando o pátio tem céu livre, há também uma escotilha de saída.
- **Cofre BR-7 (5/5)** — passa a ser ligado ao nível -2 de Blackridge por um poço de serviço no alojamento, e à Mina Profunda Westline por uma galeria. Tem laboratório, segurança, servidores, contenção e a câmara.

### Descoberta sem marcadores gratuitos
- Há um bilhete na Delegacia de North County, e dentro de cada local uma nota curta indica o próximo: onde fica, qual o perigo e o que levar.
- O rádio tem uma nova faixa, a Faixa do Xerife (88.3), que explica o código das marcas de risco.
- Mara, Lena, Jonah e Eli mencionam o local correspondente enquanto ele não foi encontrado.
- Cada entrada tem um poste com traços de 1 a 5, além de placas, farol vermelho ou símbolo biológico conforme o risco.
- Um local só entra no mapa depois de encontrado, e o rótulo no mundo também fica oculto até lá.

### Um desafio diferente em cada local
- **Xerife:** um fio com latas no vão da armaria faz barulho e acorda o abrigo. Para passar sem disparar, é preciso ir agachado ou cortar o fio com uma lâmina. A grade abre com a chave de evidências (Delegacia) ou pé de cabra.
- **Harlow:** a ala de isolamento tem contaminação (o respirador está na triagem). O controle de quarentena abre com a chave da farmácia interna da Clínica ou pé de cabra.
- **Greenwater:** o bunker fica no escuro até o quadro do gerador ser religado com 2 cabos e 1 bateria. Sem energia, a porta blindada só cede à força, com 8 golpes e muito barulho.
- **Arsenal:** os sensores ficam na altura do peito no corredor de serviço. Se o jogador passar em pé, a sirene dispara; agachado, passa por baixo. A central que desliga os sensores fica no andar de baixo, pela rota do salão. O anteparo do depósito exige a chave de manutenção (guardada no cofre de Greenwater) ou 10 golpes.
- **BR-7:** a contaminação é máxima. O cartão abre a câmara, mas dispara a sirene de contenção enquanto o bloqueio estiver armado. O console que libera o bloqueio só funciona com o quadro de energia do nível -1 de Blackridge religado.
- Os infectados de cada local agora respeitam o tipo definido (antes todos viravam errante ou observador): cambaleantes em Harlow, pesado no gerador de Greenwater, blindados no Arsenal, contidos e berrador no BR-7.

### Progressão e peso
| Local | Arma | Munição | Peso total |
|---|---|---|---|
| Abrigo do Xerife | pistola | 16 | 5,4 kg |
| Quarentena Harlow | espingarda | 8 | 9,4 kg |
| Bunker Greenwater | carabina civil | 12 | 20,2 kg |
| Arsenal do Condado | carabina policial | 24 | 25,7 kg |
| Cofre BR-7 | carabina BR-7 | 18 | 21,4 kg |

- Cada local tem uma única arma de fogo. Saíram a espingarda de serviço do Arsenal e o BR-M6 do BR-7.
- Do nível 3 em diante, a recompensa inclui carga pesada (galão, placas de aço, liga industrial, células solares, extrator de contenção). Levar tudo exige mochila adequada, veículo ou mais de uma viagem.

### Revisitas e postos
- O save registra, por local, descoberta, primeira entrada, cofre aberto, energia restaurada e conclusão, além de sensores, bloqueio e bilhetes lidos.
- Depois de abrir o cofre e limpar o local:
  - no Xerife, o catre permite dormir até o amanhecer;
  - em Harlow, a maca trata ferimentos uma vez por dia;
  - em Greenwater, com o gerador ligado, o banco de baterias carrega uma bateria por dia (no máximo duas);
  - no Arsenal, a bancada do armeiro restaura a arma selecionada com 1 peça de arma;
  - o BR-7 não vira posto.
- Um local concluído não recebe mais infectados autorais nem eventos de sala ao recarregar o jogo.

### Interface
- Ao descobrir um local, aparece por poucos segundos uma placa estêncil com o nome, o risco (■□□□□) e uma frase curta.
- As notas aparecem como papel preso e somem quando o jogador se afasta.
- Os prompts de portas e escotilhas dizem o que falta (chave ou ferramenta), quantos golpes são necessários e se o arrombamento faz barulho.
- No mapa, cada categoria tem um losango próprio: âmbar para comum, azul para subterrânea e vermelho cheio para alto risco, com legenda.

### Correções
- As portas das expedições começavam destrancadas.
- A Stage 41.0 numerava seus 18 pontos no meio dos pontos antigos, e saves v40 restauravam estados nos pontos errados. Agora os pontos da Stage 41 usam a faixa 41xxx, e a numeração antiga voltou a ser idêntica à da Stage 40.
- Os túneis da Stage 31 bloqueavam a galeria da mina até o BR-7. A entrada foi deslocada.
- O rótulo de local subterrâneo aparecia na altura do peito do jogador.

### Compatibilidade
- O save continua v41, com um bloco `stage41` na versão de layout 2.
- **Saves v40** recebem a nova geometria e os 17 containers das expedições.
- **Saves da Stage 41.0:**
  - as áreas escavadas pela versão anterior voltam ao estado do mundo gerado;
  - os ids deslocados são corrigidos;
  - containers já abertos mantêm o que restou dentro, e os intocados recebem o novo loot;
  - uma porta já aberta continua aberta;
  - um jogador que tenha salvo dentro da geometria antiga é levado à entrada do local.
- Construções feitas pelo jogador dentro das áreas antigas da Stage 41.0 podem ser sobrescritas por essa restauração.

### Validação
Passam: `validate_stage39`, `validate_stage40`, `validate_stage41` (20 seeds), `validate_assets`, `smoke` e `validate_world 6`. A revisão visual foi feita no Chrome em 1280×720 e 1920×1080, sem erros de console.

O `validate_stage31` já falhava antes desta versão: ele exige `version:31` no game.js, e o save está na versão 32+ desde o commit "versão 1.0".

---

## Stage 41.0 — Fundação

- Cinco expedições com risco de 1 a 5, containers de recompensa garantida e integração com o mapa, as portas e o sistema de estruturas.
- Save v41, com saves 22 a 40 aceitos.
