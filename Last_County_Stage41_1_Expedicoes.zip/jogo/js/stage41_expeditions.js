// Stage 41 — High-Risk Expeditions
// Five authored loot sites form a readable risk/reward ladder across Last County.
// This file deliberately extends the existing world, doors, loot, lighting and
// infected systems instead of creating a second exploration framework.
//
// Stage 41.1 (lapidação): every site now has its own geometry, entrance in a
// real gap of the map, a distinct challenge, an escape or alternative route and
// a reason to come back. Stage 41 points use a reserved id range (41xxx) so the
// ids of every older interactive point stay exactly as they were in Stage 40.

const STAGE41_LAYOUT = 2;
const S41_POINT_BASE = 41000;

// Each site: identity, map category, the short sentence shown on discovery and
// the loot of every authored container (keys are stable across versions).
const STAGE41_EXPEDITIONS = [
  {
    id:'sheriff_cache', short:'XERIFE', tier:1, slot:1, name:'Abrigo do Xerife', type:'expedition_1', visual:'responder',
    category:'comum', phrase:'Um porão cavado à mão. Alguém resistiu aqui.',
    warning:'ABRIGO DO XERIFE · SUPRIMENTOS POLICIAIS',
    events:['noise_room','lights_flicker'], infected:['wanderer','runner'],
    boxes:{
      armory:['Caixa de patrulha','police',[['pistol',1],['ammo_pistol',10],['hatchet',1],['flashlight',1]]],
      evidence:['Armário do xerife','police',[['ammo_pistol',6],['maintenance_kit',1],['bandage',2],['battery',1],['daypack',1]]]
    }
  },
  {
    id:'quarantine_camp', short:'HARLOW', tier:2, slot:2, name:'Quarentena Estadual Harlow', type:'expedition_2', visual:'patient',
    category:'comum', phrase:'Triagem de emergência sob o hospital. O ar ainda pesa.',
    warning:'QUARENTENA HARLOW · ACESSO RESTRITO',
    events:['emergency_lights','sector_wake','noise_room'], infected:['lurcher','wanderer','runner'],
    boxes:{
      triage:['Suprimentos de triagem','medical',[['bandage',3],['disinfectant',1],['respirator',1],['medical_gloves',1]]],
      guard:['Contêiner da guarda','police',[['shotgun',1],['ammo_shotgun',8],['police_baton',1]]],
      isolation:['Armário de isolamento','medical',[['medicine',3],['disinfectant',1],['medical_pack',1]]]
    }
  },
  {
    id:'greenwater_bunker', short:'GREENWATER', tier:3, slot:3, name:'Bunker Civil Greenwater', type:'expedition_3', visual:'rural',
    category:'subterrânea', phrase:'Um abrigo de família, apagado desde que o gerador morreu.',
    warning:'BUNKER GREENWATER · AUTONOMIA CIVIL',
    events:['noise_room','machine_noise','sector_wake'], infected:['heavy','stalker','runner','wanderer'],
    boxes:{
      workshop:['Oficina do gerador','industrial',[['wire',3],['fuse',2],['pump_parts',1],['fuel_can',1]]],
      pantry:['Despensa de emergência','holdout',[['canned_food',4],['water_bottle',4],['expedition_meal',2],['seed_corn',3],['seed_potato',3],['fertilizer',2]]],
      grow:['Canteiro abandonado','farm',[['grow_lamp',1],['seed_carrot',2],['seed_cabbage',2],['fertile_soil',3]]],
      vault:['Cofre dos moradores','police',[['civilian_carbine',1],['ammo_carbine',12],['hiking_pack',1],['maintenance_key',1],['water_filter',1]]]
    }
  },
  {
    id:'county_arsenal', short:'ARSENAL', tier:4, slot:4, name:'Arsenal Subterrâneo do Condado', type:'expedition_4', visual:'responder',
    category:'alto risco', phrase:'Anteparos, sensores e o depósito que o condado escondeu.',
    warning:'ARSENAL DO CONDADO · AMEAÇA SEVERA',
    events:['metal_clang','sector_wake','lights_flicker'], infected:['armored','heavy','runner'],
    boxes:{
      guard:['Armário da guarda','police',[['ammo_carbine',8],['tactical_boots',1],['patrol_gloves',1]]],
      maintenance:['Reserva de manutenção','industrial',[['weapon_parts',4],['precision_parts',2],['maintenance_kit',2],['steel_plate',4]]],
      crate:['Engradado de blindagem','industrial',[['steel_plate',6],['industrial_alloy',2],['police_vest',1]]],
      vault:['Cofre do arsenal','police',[['police_carbine',1],['ammo_carbine',16],['police_helmet',1],['patrol_pack',1]]]
    }
  },
  {
    id:'blackridge_vault', short:'BR-7', tier:5, slot:5, name:'Cofre Tecnológico Blackridge', type:'expedition_5', visual:'blackridge',
    category:'alto risco', phrase:'BR-7: o que Blackridge não quis evacuar.',
    warning:'BLACKRIDGE BR-7 · CONTENÇÃO MÁXIMA',
    events:['emergency_lights','sector_wake','alarm','lights_flicker'], infected:['contained','armored','stalker','screamer'],
    boxes:{
      lab:['Componentes experimentais','blackridge',[['optic_module',1],['stability_module',1],['handling_module',1],['precision_parts',3],['circuit_parts',3]]],
      power:['Bancada de energia','blackridge',[['solar_cell',4],['battery',2],['power_controller',1],['industrial_alloy',3]]],
      containment:['Armário de contenção','blackridge',[['blackridge_helmet',1],['filter_cartridge',2],['containment_cutter',1]]],
      vault:['Cofre BR-7','blackridge',[['blackridge_carbine',1],['ammo_carbine',18],['blackridge_vest',1],['blackridge_pack',1]]]
    }
  }
];

// Short field notes. Each one points to the next site with world language —
// place, danger and preparation — instead of a marker on the map.
const STAGE41_NOTES = {
  police_note:{title:'Bilhete do xerife',text:'Levei o que sobrou da delegacia para o porão da Estrada 17, entre a Lavoura Harlow e os trailers. A chave de evidências abre a grade. Marquei a entrada com um traço: um traço, pouco perigo; cinco, não desça.'},
  sheriff_map:{title:'Mapa do xerife',text:'Harlow montou triagem embaixo do pátio cercado do hospital. Guardas armados, pacientes isolados, ar ruim no fundo. Leve curativos e algo para respirar. Dois traços.'},
  harlow_log:{title:'Registro de triagem',text:'Famílias de Greenwater têm bunker próprio no campo depois da horta comunitária. Gerador morto: 2 cabos e 1 bateria no quadro, ou a porta blindada não abre. Três traços.'},
  greenwater_diary:{title:'Diário do morador',text:'O condado guardava armas sob o pátio ferroviário de Westline. Sensores na altura do peito vigiam o corredor de serviço; a central fica no andar de baixo. A chave de manutenção ficou no nosso cofre. Quatro traços.'},
  arsenal_order:{title:'Ordem de transferência',text:'Material BR-7 retido sob o nível -2 de Blackridge, pelo poço do alojamento ou pela galeria da mina profunda. Contaminação total: traje e filtro. O console de bloqueio só responde com o quadro do nível -1 religado. Cinco traços.'},
  br7_report:{title:'Relatório BR-7',text:'Bloqueio automático armado. Cartão abre a câmara, mas dispara a sirene se o console da segurança não for liberado antes.'}
};

// Stage 41.0 footprints, kept only to repair saves written by that build.
const STAGE41_LEGACY = [
  {id:'sheriff_cache', x0:1080, x1:1112, floor:104, shaft:1083, points:['door','hatch','light']},
  {id:'quarantine_camp', x0:622, x1:650, floor:119, shaft:625, points:['door','hatch','light']},
  {id:'greenwater_bunker', x0:1304, x1:1344, floor:126, shaft:1307, points:['door','hatch','light','alarm']},
  {id:'county_arsenal', x0:738, x1:784, floor:148, shaft:741, points:['door','hatch','light','alarm']},
  {id:'blackridge_vault', x0:880, x1:930, floor:164, shaft:880, tunnel:[873,880,150,154], points:['door','hatch','light','alarm']}
];

for (const def of STAGE41_EXPEDITIONS) {
  STRUCTURE_PROFILES[def.type] = {
    loot:def.tier >= 5 ? 'blackridge' : def.tier >= 4 ? 'police' : def.tier === 3 ? 'holdout' : def.tier === 2 ? 'medical' : 'police',
    ambient:def.tier >= 5 ? 'blackridge' : def.tier >= 3 ? 'metro' : 'industrial',
    danger:def.tier,
    events:[...def.events],
    states:{intact:1}
  };
  AREA_PROFILES[def.type] = { visual:def.visual, types:[...def.infected] };
}

/* ------------------------------------------------------------ carving */

// Solid shell around an interior. Unlike vault() this never leaves the side
// open into a natural cave: every opening of a Stage 41 site is authored.
StructureManager.prototype.s41Box = function(x0, x1, y0, y1, shell, back, floor = null) {
  const w = this.world;
  for (let x = x0 - 1; x <= x1 + 1; x++) {
    for (let y = y0 - 1; y <= y1 + 1; y++) {
      const edge = x < x0 || x > x1 || y < y0 || y > y1;
      w.set(x, y, edge ? shell : TILE.AIR);
      w.setWall(x, y, back);
    }
  }
  if (floor) for (let x = x0; x <= x1; x++) w.set(x, y1 + 1, floor);
};

// Partition column; `gapRows` rows above the floor stay open.
StructureManager.prototype.s41Partition = function(x, y0, floorY, tile, gapRows = 2) {
  for (let y = y0; y < floorY; y++) this.world.set(x, y, y >= floorY - gapRows ? TILE.AIR : tile);
};

StructureManager.prototype.s41Skin = function(x0, x1, y0, y1, back, floor = null, floorY = null) {
  for (let x = x0; x <= x1; x++) {
    for (let y = y0; y <= y1; y++) this.world.setWall(x, y, back);
    if (floor && floorY != null) this.world.set(x, floorY, floor);
  }
};

// Vertical access: a catwalk cap at the top (so the surface or floor above is
// never an open hole) and a ladder down to `yBottom`.
StructureManager.prototype.s41Shaft = function(x, capY, yBottom, back, cap = TILE.CATWALK) {
  const w = this.world;
  if (cap) w.set(x, capY, cap);
  for (let y = capY + 1; y <= yBottom; y++) { w.set(x, y, TILE.LADDER); w.setWall(x, y, back); }
};

// Clears loose obstacles (fences, rubble, foliage) above an entrance so the
// player always has standing room. Building walls are never touched.
const S41_LOOSE = new Set([TILE.FENCE, TILE.CHAIN_FENCE, TILE.RUBBLE, TILE.LEAF, TILE.TALL_GRASS, TILE.DEAD_GRASS,
  TILE.DRY_FLOWERS, TILE.BERRY_BUSH, TILE.VINE, TILE.WOOD, TILE.SANDBAG]);
StructureManager.prototype.s41Headroom = function(x, groundY, rows = 3) {
  for (let y = groundY - rows; y < groundY; y++) if (S41_LOOSE.has(this.world.get(x, y))) this.world.set(x, y, TILE.AIR);
};

StructureManager.prototype.s41Surface = function(x0, x1) {
  let max = 0;
  for (let x = x0; x <= x1; x++) max = Math.max(max, this.world.surface[x]);
  return max;
};

/* ------------------------------------------------------------ geometry */

// Geometry is computed once from the generated world and kept on the
// manager, so old saves are re-carved with exactly the same numbers.
StructureManager.prototype.s41Geometry = function(def) {
  this.s41Geo = this.s41Geo || {};
  if (this.s41Geo[def.id]) return this.s41Geo[def.id];
  const w = this.world, g = { id:def.id };
  if (def.id === 'sheriff_cache') {
    g.x0 = 174; g.x1 = 198; g.hx = 184; g.tx = 167;
    g.floor = this.s41Surface(166, 200) + 9;
    g.top = g.floor - 5;
    g.hs = w.surface[g.hx]; g.ts = w.surface[g.tx];
  } else if (def.id === 'quarantine_camp') {
    const h = this.structures.find(s => s.type === 'hospital');
    const hg = h ? h.groundY : w.surface[665];
    g.x0 = 643; g.x1 = 690; g.hx = 651; g.lx = 673;
    g.floor = hg + 19;
    g.top = g.floor - 6;
    g.hs = w.surface[g.hx];
    // The hospital basement (construct() basement: floor slab at groundY+8)
    // becomes the quarantine's back door when it is really there.
    const bf = hg + 8;
    g.basementFloor = w.get(g.lx, bf - 1) === TILE.AIR && w.getWall(g.lx, bf - 1) !== TILE.AIR && TILE_INFO[w.get(g.lx, bf)]?.solid ? bf : null;
  } else if (def.id === 'greenwater_bunker') {
    g.x0 = 1314; g.x1 = 1360; g.hx = 1317;
    g.floor = this.s41Surface(1312, 1362) + 10;
    g.top = g.floor - 6;
    g.hs = w.surface[g.hx];
    let ex = 1349;
    for (let x = 1347; x <= 1351; x++) if (w.surface[x] > w.surface[ex]) ex = x;
    g.ex = ex; g.es = w.surface[ex];
  } else if (def.id === 'county_arsenal') {
    g.x0 = 744; g.x1 = 792; g.ux1 = 786; g.hx = 748;
    g.upper = this.s41Surface(742, 794) + 9;
    g.floor = g.upper + 7;
    g.top = g.upper - 4;
    g.hs = w.surface[g.hx];
    // Escape hatch to the rail yard: only where the sky is really open.
    g.ex = null;
    for (let x = 784; x >= 770; x--) {
      const s = w.surface[x];
      const clear = !this.containers.some(c => Math.hypot(c.x / CONFIG.TILE - x, c.y / CONFIG.TILE - s) < 4);
      if (clear && [1, 2, 3].every(d => w.get(x, s - d) === TILE.AIR && w.getWall(x, s - d) === TILE.AIR) && ![760, 767, 774, 779, 781].includes(x)) { g.ex = x; g.es = s; break; }
    }
  } else if (def.id === 'blackridge_vault') {
    g.x0 = 870; g.x1 = 930; g.floor = 164; g.top = 157;
    g.tunnelX = 872; g.shaftX = 877; g.shaftTop = 149;
  }
  this.s41Geo[def.id] = g;
  return g;
};

// Tiles only. Safe to run again on a loaded world (old saves).
StructureManager.prototype.s41Carve = function(def) {
  const g = this.s41Geometry(def), T = TILE, F = g.floor;
  if (def.id === 'sheriff_cache') {
    this.s41Box(g.x0, g.x1, F - 4, F - 1, T.OLD_CONCRETE, T.DIRTY_CONCRETE, T.OLD_WOOD);
    this.s41Skin(183, 190, F - 4, F - 1, T.TIMBER);
    this.s41Skin(192, 198, F - 4, F - 1, T.OLD_CONCRETE, T.CHECKER_FLOOR, F);
    this.s41Partition(182, F - 4, F, T.TIMBER);
    this.s41Partition(191, F - 4, F, T.OLD_CONCRETE);
    this.world.set(178, F - 1, T.SANDBAG);
    // escape tunnel to the Lavoura Harlow field
    for (let x = g.tx + 1; x <= g.x0 - 1; x++) {
      for (let y = F - 2; y <= F - 1; y++) { this.world.set(x, y, T.AIR); this.world.setWall(x, y, T.TIMBER); }
      this.world.set(x, F - 3, T.DIRT); this.world.set(x, F, T.DIRT);
    }
    this.s41Shaft(g.tx, g.ts, F - 1, T.TIMBER);
    this.world.set(g.tx, F, T.DIRT);
    this.s41Headroom(g.tx, g.ts);
    this.s41Shaft(g.hx, g.hs, F - 1, T.TIMBER);
    this.s41Headroom(g.hx, g.hs);
  } else if (def.id === 'quarantine_camp') {
    this.s41Box(g.x0, g.x1, F - 5, F - 1, T.CONCRETE, T.WALL_TILE, T.LINOLEUM);
    this.s41Skin(659, 675, F - 5, F - 1, T.OLD_CONCRETE, T.CHECKER_FLOOR, F);
    this.s41Skin(677, 690, F - 5, F - 1, T.CONTAINMENT, T.LAB_FLOOR, F);
    this.s41Partition(658, F - 5, F, T.CONCRETE);
    this.s41Partition(676, F - 5, F, T.CONTAINMENT);
    this.world.set(669, F - 1, T.SANDBAG);
    this.s41Shaft(g.hx, g.hs, F - 1, T.CONCRETE);
    this.s41Headroom(g.hx, g.hs);
    if (g.basementFloor != null) this.s41Shaft(g.lx, g.basementFloor, F - 1, T.CONCRETE);
  } else if (def.id === 'greenwater_bunker') {
    this.s41Box(g.x0, g.x1, F - 5, F - 1, T.CONCRETE, T.CONCRETE, T.INDUSTRIAL_FLOOR);
    this.s41Skin(1323, 1331, F - 5, F - 1, T.IND_PANEL);
    this.s41Skin(1333, 1341, F - 5, F - 1, T.WALLPAPER_WARM, T.CARPET, F);
    this.s41Skin(1343, 1352, F - 5, F - 1, T.OLD_CONCRETE);
    for (let x = 1347; x <= 1351; x++) this.world.set(x, F, T.WET_DIRT);
    this.s41Skin(1354, 1360, F - 5, F - 1, T.DARK_METAL);
    this.s41Partition(1322, F - 5, F, T.CONCRETE);
    this.s41Partition(1332, F - 5, F, T.CONCRETE);
    this.s41Partition(1342, F - 5, F, T.CONCRETE);
    this.s41Partition(1353, F - 5, F, T.CONCRETE);
    this.s41Shaft(g.hx, g.hs, F - 1, T.CONCRETE);
    this.s41Headroom(g.hx, g.hs);
    // one-way emergency exit, sealed from the inside until opened
    this.s41Shaft(g.ex, g.es, F - 1, T.CONCRETE, T.METAL);
  } else if (def.id === 'county_arsenal') {
    const U = g.upper;
    this.s41Box(g.x0, g.ux1, U - 3, U - 1, T.RUST_METAL, T.TECH_WALL, T.GRATE);
    this.s41Box(g.x0, g.x1, F - 5, F - 1, T.RUST_METAL, T.IND_PANEL, T.HAZARD_FLOOR);
    this.s41Skin(g.x0, 752, U - 3, U - 1, T.OLD_CONCRETE);
    this.s41Skin(783, g.x1, F - 5, F - 1, T.DARK_METAL, T.INDUSTRIAL_FLOOR, F);
    this.s41Partition(753, U - 3, U, T.RUST_METAL);
    this.s41Partition(781, U - 3, U, T.RUST_METAL);
    this.s41Partition(757, F - 5, F, T.RUST_METAL);
    this.s41Partition(782, F - 5, F, T.DARK_METAL);
    this.s41Shaft(g.hx, g.hs, U - 1, T.OLD_CONCRETE);
    this.s41Headroom(g.hx, g.hs);
    this.s41Shaft(751, U, F - 1, T.TECH_WALL);
    this.s41Shaft(779, U, F - 1, T.TECH_WALL);
    if (g.ex != null) this.s41Shaft(g.ex, g.es, U - 1, T.TECH_WALL, T.METAL);
  } else if (def.id === 'blackridge_vault') {
    this.s41Box(g.x0, g.x1, F - 6, F - 1, T.TECH_WALL, T.WALL_PANEL, T.INDUSTRIAL_FLOOR);
    this.s41Skin(879, 890, F - 6, F - 1, T.LAB_WALL, T.LAB_FLOOR, F);
    this.s41Skin(904, 915, F - 6, F - 1, T.TECH_PANEL, T.TECH_FLOOR, F);
    this.s41Skin(917, 924, F - 6, F - 1, T.CONTAINMENT, T.LAB_FLOOR, F);
    this.s41Skin(926, 930, F - 6, F - 1, T.DARK_METAL);
    this.s41Partition(878, F - 6, F, T.TECH_WALL, 3);
    this.s41Partition(891, F - 6, F, T.TECH_WALL, 3);
    this.s41Partition(903, F - 6, F, T.TECH_WALL, 3);
    this.s41Partition(916, F - 6, F, T.CONTAINMENT, 3);
    this.s41Partition(925, F - 6, F, T.DARK_METAL);
    // west route: the Westline deep mine gallery
    this.world.digTunnel(854, g.tunnelX, 153, 3, T.DARK_STONE, T.GRAVEL);
    this.s41Shaft(g.tunnelX, 153, F - 1, T.DARK_METAL, null);
    // main route: service shaft from Blackridge level -2 (dormitory)
    this.s41Shaft(g.shaftX, g.shaftTop, F - 1, T.DARK_METAL);
  }
};

/* ------------------------------------------------------------- dressing */

StructureManager.prototype.s41Point = function(def, slot, kind, tileX, tileY, data = {}) {
  const p = this.addPoint(kind, tileX, tileY, { ...data, s41:def.id, s41Slot:slot });
  // addPoint consumed a legacy id; give it back so older points keep theirs.
  this.nextPointId--;
  p.id = S41_POINT_BASE + def.slot * 100 + slot;
  return p;
};

StructureManager.prototype.s41Door = function(def, slot, tileX, tileY, opts) {
  const p = this.s41Point(def, slot, 'door', tileX, tileY, {
    name:opts.name, height:2, tile:opts.tile || TILE.PLANK, locked:Boolean(opts.locked),
    keyItem:opts.keyItem || null, forceTool:opts.forceTool || 'crowbar', integrity:opts.integrity ?? 3,
    area:def.name, vault:Boolean(opts.vault), masc:Boolean(opts.masc)
  });
  for (let i = 0; i < 2; i++) this.world.set(tileX, tileY - i, p.tile);
  return p;
};

StructureManager.prototype.s41Box2 = function(def, key, tileX, floorY) {
  const [name, category, loot] = def.boxes[key];
  const box = this.addContainer(name, tileX, floorY - 2, category, loot.map(([id, qty]) => ({ id, qty })), { rare:key === 'vault' || def.tier >= 3 });
  box.stage41 = true; box.expeditionId = def.id; box.riskTier = def.tier; box.stage41Key = `${def.id}:${key}`;
  // authored loot: the Greenwater forage pass (Stage 40) leaves these boxes alone
  box.stage40Loot = true;
  if (key === 'vault' || (def.id === 'sheriff_cache' && key === 'evidence') || (def.id === 'quarantine_camp' && key === 'guard')) box.stage41Vault = true;
  return box;
};

StructureManager.prototype.s41Spawn = function(list, x, y, visual, type) { list.push([x, y, visual, type]); };

StructureManager.prototype.stage41BuildSite = function(def) {
  this.plan(def.type, def.slot * 1000 + 41, { state:'intact' });
  this.s41Carve(def);
  const g = this.s41Geometry(def), F = g.floor, T = CONFIG.TILE, TL = TILE;
  const fp = (a, x, y, o = {}) => this.floorProp(a, x, y, { scale:1, ...o });
  const wp = (a, x, y, h, o = {}) => this.wallProp(a, x, y, h, o);
  const lamp = (x, y, kind, o = {}) => this.lamp((x + .5) * T, y * T, {
    radius:o.radius || 150, strength:o.strength ?? .62,
    color:kind === 'emergency' || kind === 'beacon' ? 'red' : kind === 'fluoro' ? 'cold' : 'warm',
    mode:kind === 'fluoro' ? 'power' : kind === 'emergency' ? 'emergency' : 'always',
    flicker:o.flicker ?? (kind === 'emergency' || kind === 'beacon' ? .4 : .12),
    fixture:kind === 'fluoro' ? 'tube' : kind === 'lantern' ? 'lantern' : kind === 'bulb' ? 'bulb' : 'emergency'
  });
  const tube = (x, ceilY, floorY) => { this.ceilProp('fluoro_lamp', x, ceilY, floorY, { scale:1, offsetX:-2 }); lamp(x, ceilY + 1.4, 'fluoro', { radius:190, strength:.82 }); };
  const rooms = [], spawns = [], entrances = [], hazards = [], sensors = [];
  const room = (x0, x1, floorY, ceilY) => { const r = { x0, x1, floorY, ceilY }; rooms.push(r); return r; };
  const extra = {};

  if (def.id === 'sheriff_cache') {
    room(174, 181, F, F - 5); room(183, 190, F, F - 5); room(192, 198, F, F - 5);
    // armoury: sandbags, racks, an improvised last stand
    fp('cardboard_box', 175, F); fp('crate_stack', 177, F); fp('locker', 180, F);
    wp('gun_rack', 179, F, 62); wp('plank_barricade', 174, F, 6, { scale:.8, alpha:.9 });
    this.s41Box2(def, 'armory', 176, F);
    // rest area: the only light in the shelter
    fp('water_jugs', 183, F); fp('bunk_bed', 185, F); fp('candles', 187, F); fp('table', 188, F); fp('radio', 189, F, { scale:.9, offsetY:-22 });
    wp('corkboard', 188, F, 58);
    this.ceilProp('lantern', 186, F - 5, F, { scale:1 });
    lamp(186, F - 3.4, 'lantern', { radius:150, strength:.7 });
    fp('bottles', 182, F, { scale:.9 });
    // evidence room behind the grate
    fp('shelf', 192, F); fp('filing_cabinet', 194, F); fp('papers', 195, F); fp('box_open', 197, F); fp('cardboard_box', 198, F);
    this.s41Box2(def, 'evidence', 196, F);
    // surface: a timber hatch hidden in the verge, and the tunnel hatch in the field
    this.addProp('bush', g.hx - 1, g.hs - 1, { scale:.9, behind:true, anim:'sway' });
    this.addProp('bush', g.tx - 1, g.ts - 1, { scale:.85, behind:true, anim:'sway' });
    this.s41Point(def, 1, 'hatch', g.hx, g.hs - 1, { name:'Alçapão do xerife', targetX:g.hx, targetY:F, label:'DESCER AO ABRIGO DO XERIFE' });
    this.s41Point(def, 2, 'hatch', g.tx, g.ts - 1, { name:'Túnel de fuga do xerife', targetX:g.tx + 1, targetY:F, label:'DESCER PELO TÚNEL DE FUGA' });
    this.s41Door(def, 3, 191, F - 1, { name:'Grade do depósito', tile:TL.CHAIN_FENCE, locked:true, keyItem:'evidence_key', forceTool:'crowbar', integrity:3, vault:true });
    this.s41Point(def, 4, 's41_note', 188, F - 1, { name:'Mapa do xerife', note:'sheriff_map' });
    this.s41Point(def, 5, 's41_tripwire', 182, F - 1, { name:'Fio com latas', state:'armed' });
    this.s41Point(def, 6, 's41_rest', 185, F - 1, { name:'Catre do xerife' });
    entrances.push({ x:g.hx, y:g.hs - 1 }, { x:g.tx, y:g.ts - 1 });
    this.s41Spawn(spawns, 177, F, 'responder', 'wanderer');
    this.s41Spawn(spawns, 180, F, 'responder', 'runner');
    this.s41Spawn(spawns, 195, F, 'civilian', 'wanderer');
    extra.landing = { x:g.hx, y:F };
  } else if (def.id === 'quarantine_camp') {
    room(643, 657, F, F - 6); room(659, 675, F, F - 6); room(677, 690, F, F - 6);
    // triage
    fp('med_cart', 644, F); fp('gurney', 647, F); fp('privacy_curtain', 652, F); fp('wheelchair', 654, F); fp('iv_stand', 656, F);
    wp('biohazard_sign', 655, F, 96); wp('corkboard', 654, F, 60);
    this.s41Box2(def, 'triage', 646, F);
    // security post
    fp('office_desk', 660, F); fp('monitor_stand', 662, F); fp('locker', 664, F); fp('crate_stack', 671, F); fp('filing_cabinet', 674, F);
    wp('gun_rack', 667, F, 64); wp('security_camera', 672, F, 120);
    this.s41Box2(def, 'guard', 666, F);
    // isolation: plastic curtain at the door, beds, bins, heavy air
    fp('privacy_curtain', 676, F, { alpha:.85 }); fp('hospital_bed', 678, F); fp('biohazard_bin', 681, F); fp('hospital_bed', 682, F);
    fp('iv_stand', 685, F); fp('privacy_curtain', 688, F);
    wp('biohazard_sign', 680, F, 96); wp('biohazard_sign', 689, F, 96);
    this.s41Box2(def, 'isolation', 686, F);
    this.emitter('drip', 683 * T, (F - 5) * T);
    this.emitter('steam', 687 * T, (F - 2) * T, { rate:.35 });
    for (const x of [650, 667, 684]) lamp(x, F - 5 + 1.2, 'emergency', { radius:160, strength:.62 });
    // surface checkpoint in the hospital's fenced yard
    this.addProp('warning_sign', g.hx - 1, g.hs - 1, { scale:.85, behind:true });
    this.addProp('road_barrier', g.hx + 2, g.hs - 1, { scale:.9 });
    this.addProp('biohazard_sign', g.hx + 1, g.hs - 1, { scale:1, behind:true, wall:true, offsetY:-44 });
    lamp(g.hx, g.hs - 2.2, 'beacon', { radius:120, strength:.55, flicker:.55 });
    this.s41Point(def, 1, 'hatch', g.hx, g.hs - 1, { name:'Acesso da quarentena', targetX:g.hx, targetY:F, label:'DESCER À QUARENTENA HARLOW' });
    this.s41Door(def, 2, 658, F - 1, { name:'Controle de quarentena', masc:true, tile:TL.METAL, locked:true, keyItem:'clinic_key', forceTool:'crowbar', integrity:5, vault:true });
    this.s41Point(def, 3, 's41_note', 654, F - 1, { name:'Registro de triagem', note:'harlow_log' });
    this.s41Point(def, 4, 's41_station', 650, F - 1, { name:'Maca de triagem', station:'medical' });
    hazards.push({ kind:'contamination', x0:677, x1:690, y0:F - 5, y1:F - 1, k:.38 });
    entrances.push({ x:g.hx, y:g.hs - 1 });
    if (g.basementFloor != null) { entrances.push({ x:g.lx, y:g.basementFloor - 1 }); wp('biohazard_sign', g.lx + 1, g.basementFloor, 60); }
    this.s41Spawn(spawns, 648, F, 'patient', 'wanderer');
    this.s41Spawn(spawns, 663, F, 'responder', 'wanderer');
    this.s41Spawn(spawns, 670, F, 'responder', 'runner');
    this.s41Spawn(spawns, 680, F, 'patient', 'lurcher');
    this.s41Spawn(spawns, 687, F, 'patient', 'lurcher');
    extra.landing = { x:g.hx, y:F };
  } else if (def.id === 'greenwater_bunker') {
    room(1314, 1321, F, F - 6); room(1323, 1331, F, F - 6); room(1333, 1341, F, F - 6); room(1343, 1352, F, F - 6); room(1354, 1360, F, F - 6);
    // airlock: a single battery lantern marks the only safe spot
    fp('locker', 1319, F); fp('water_jugs', 1315, F); wp('warning_sign', 1320, F, 56, { scale:.8 });
    lamp(1316, F - 3.2, 'bulb', { radius:95, strength:.45, flicker:.3 });
    // generator room
    fp('cable_spool', 1323, F); fp('generator', 1326, F); fp('electrical_panel', 1330, F); fp('gas_cylinders', 1331, F);
    this.s41Box2(def, 'workshop', 1325, F);
    // dormitory
    fp('bunk_bed', 1333, F); fp('bunk_bed', 1336, F); fp('dresser', 1338, F); fp('table', 1340, F);
    wp('picture_frame', 1335, F, 70); wp('wall_clock', 1339, F, 84);
    // pantry and the abandoned grow room
    fp('shelf', 1343, F); fp('water_jugs', 1344, F); fp('shelf', 1346, F); fp('garden_bed', 1348, F); fp('crop_row', 1350, F, { scale:.9, alpha:.8 });
    fp('planter', 1352, F);
    this.s41Box2(def, 'pantry', 1345, F);
    this.s41Box2(def, 'grow', 1350, F);
    // residents' vault
    fp('crate_stack', 1355, F); fp('tool_cabinet', 1357, F); fp('cardboard_box', 1360, F);
    this.s41Box2(def, 'vault', 1358, F);
    for (const [x0, x1] of [[1314, 1321], [1323, 1331], [1333, 1341], [1343, 1352], [1354, 1360]]) tube(Math.floor((x0 + x1) / 2), F - 6, F);
    // surface: a concrete hatch and a vent stack in the open field
    this.addProp('vent_pipe', g.hx - 2, g.hs - 1, { scale:1, behind:true });
    this.addProp('warning_sign', g.hx + 1, g.hs - 1, { scale:.85, behind:true });
    this.addProp('vent_pipe', g.ex + 1, g.es - 1, { scale:.8, behind:true });
    this.s41Point(def, 1, 'hatch', g.hx, g.hs - 1, { name:'Escotilha Greenwater', targetX:g.hx, targetY:F, label:'DESCER AO BUNKER GREENWATER' });
    this.s41Point(def, 2, 'fuse_panel', 1329, F - 1, { name:'Quadro do gerador', state:'off', area:def.name });
    const shutter = this.s41Point(def, 3, 'shutter', 1342, F - 1, { name:'Porta blindada Greenwater', width:1, height:2, tile:TL.DARK_METAL, forceTool:'crowbar', integrity:8, area:def.name, vault:true });
    for (let i = 0; i < 2; i++) this.world.set(1342, F - 1 - i, shutter.tile);
    this.s41Point(def, 4, 's41_note', 1334, F - 1, { name:'Diário do morador', note:'greenwater_diary' });
    this.s41Point(def, 5, 's41_station', 1339, F - 1, { name:'Banco de baterias', station:'battery' });
    this.s41Point(def, 6, 's41_escape', g.ex, g.es + 1, { name:'Escotilha de emergência', coverY:g.es, state:'closed' });
    entrances.push({ x:g.hx, y:g.hs - 1 }, { x:g.ex, y:g.es - 1 });
    this.s41Spawn(spawns, 1320, F, 'rural', 'wanderer');
    this.s41Spawn(spawns, 1327, F, 'rural', 'heavy');
    this.s41Spawn(spawns, 1337, F, 'civilian', 'stalker');
    this.s41Spawn(spawns, 1346, F, 'rural', 'runner');
    this.s41Spawn(spawns, 1356, F, 'rural', 'wanderer');
    extra.landing = { x:g.hx, y:F };
  } else if (def.id === 'county_arsenal') {
    const U = g.upper;
    room(744, 752, U, U - 4); room(754, 780, U, U - 4); room(782, 786, U, U - 4);
    room(744, 756, F, F - 6); room(758, 781, F, F - 6); room(783, 792, F, F - 6);
    // upper guard post and the service corridor
    fp('locker', 744, U); fp('office_desk', 746, U, { scale:.9 }); fp('monitor_stand', 750, U, { scale:.85 });
    this.s41Box2(def, 'guard', 745, U);
    for (const x of [756, 766, 776]) this.addProp('pipe_run', x, U - 3, { scale:.95, behind:true, wall:true, offsetY:-6 });
    wp('vent_fan', 762, U, 66, { scale:.8 }); wp('cable_bundle', 771, U, 70, { scale:.9 });
    for (const x of [760, 767, 774]) { wp('br_sensor', x, U, 36); sensors.push({ x, beamY:U * T - 42 }); }
    fp('filing_cabinet', 783, U, { scale:.85 }); fp('radio', 785, U, { scale:.9 });
    // lower: maintenance, main hall, vault
    fp('tool_cabinet', 744, F); fp('electrical_panel', 746, F); fp('workbench', 748, F); fp('compressor', 753, F);
    this.s41Box2(def, 'maintenance', 754, F);
    fp('gear_rack', 759, F); fp('pallet_rack', 762, F); fp('crate_stack', 765, F); fp('hazard_barrel', 768, F);
    fp('gear_rack', 771, F); fp('pallet_rack', 774, F); fp('hazard_barrel', 777, F);
    this.s41Box2(def, 'crate', 766, F);
    wp('gun_rack', 784, F, 66); wp('gun_rack', 788, F, 66); fp('locker', 791, F); fp('crate_stack', 784, F); fp('workbench', 786, F, { scale:.9 });
    this.s41Box2(def, 'vault', 790, F);
    for (const x of [748, 767, 787]) lamp(x, F - 6 + 1.2, 'emergency', { radius:170, strength:.64 });
    for (const x of [748, 764, 784]) lamp(x, U - 4 + 1.1, 'emergency', { radius:130, strength:.55 });
    tube(767, F - 6, F);
    // surface: a service stair between the workshop and the rail yard
    this.addProp('warning_sign', g.hx - 1, g.hs - 1, { scale:.85, behind:true });
    this.addProp('floodlight_prop', g.hx + 1, g.hs - 1, { scale:.8, behind:true });
    lamp(g.hx + 1, g.hs - 2.4, 'beacon', { radius:110, strength:.5, flicker:.5 });
    this.s41Point(def, 1, 'hatch', g.hx, g.hs - 1, { name:'Escada de serviço do arsenal', targetX:g.hx, targetY:U, label:'DESCER AO ARSENAL DO CONDADO' });
    this.s41Point(def, 2, 'alarm', 749, U - 1, { name:'Sirene do arsenal', state:'off', area:def.name });
    this.s41Door(def, 3, 757, F - 1, { name:'Anteparo de serviço', masc:true, tile:TL.METAL, locked:false, integrity:4 });
    this.s41Door(def, 4, 782, F - 1, { name:'Anteparo do arsenal', masc:true, tile:TL.DARK_METAL, locked:true, keyItem:'maintenance_key', forceTool:'crowbar', integrity:10, vault:true });
    this.s41Point(def, 5, 's41_panel', 746, F - 1, { name:'Central dos sensores' });
    this.s41Point(def, 6, 's41_note', 784, U - 1, { name:'Ordem de transferência', note:'arsenal_order' });
    this.s41Point(def, 7, 's41_station', 786, F - 1, { name:'Bancada do armeiro', station:'armory' });
    if (g.ex != null) {
      this.s41Point(def, 8, 's41_escape', g.ex, g.es + 1, { name:'Escotilha do pátio', coverY:g.es, state:'closed' });
      entrances.push({ x:g.ex, y:g.es - 1 });
    }
    entrances.push({ x:g.hx, y:g.hs - 1 });
    this.s41Spawn(spawns, 757, U, 'responder', 'armored');
    this.s41Spawn(spawns, 745, F, 'worker', 'wanderer');
    this.s41Spawn(spawns, 763, F, 'responder', 'heavy');
    this.s41Spawn(spawns, 769, F, 'worker', 'armored');
    this.s41Spawn(spawns, 775, F, 'responder', 'runner');
    this.s41Spawn(spawns, 789, F, 'responder', 'armored');
    extra.landing = { x:g.hx, y:U };
  } else if (def.id === 'blackridge_vault') {
    room(870, 877, F, F - 7); room(879, 890, F, F - 7); room(892, 902, F, F - 7); room(904, 915, F, F - 7); room(917, 924, F, F - 7); room(926, 930, F, F - 7);
    // airlock where both routes arrive
    fp('hazard_barrel', 870, F); wp('br_evac_mark', 874, F, 70); wp('biohazard_sign', 871, F, 110);
    // research lab
    fp('lab_console', 879, F); fp('specimen_shelf', 881, F); fp('computer_desk', 886, F); fp('br_crate', 889, F);
    this.s41Box2(def, 'lab', 884, F);
    // security post with the lockdown console
    fp('office_desk', 893, F); fp('monitor_stand', 898, F); fp('locker', 901, F);
    wp('security_camera', 897, F, 150); wp('br_wall_panel', 894, F, 80);
    // servers
    fp('server_rack', 904, F); fp('server_rack', 906, F); fp('server_rack', 911, F); fp('server_rack', 913, F); wp('br_cable_run', 909, F, 150);
    this.s41Box2(def, 'power', 908, F);
    // containment
    fp('containment_pod', 917, F); fp('lab_console', 918, F, { scale:.85 }); fp('containment_pod', 922, F, { flip:true }); wp('biohazard_sign', 919, F, 120);
    this.s41Box2(def, 'containment', 920, F);
    // the BR-7 chamber
    fp('br_crate', 927, F); wp('gun_rack', 928, F, 70);
    this.s41Box2(def, 'vault', 929, F);
    for (const [x0, x1] of [[870, 877], [879, 890], [892, 902], [904, 915], [917, 924], [926, 930]]) {
      const cx = Math.floor((x0 + x1) / 2);
      lamp(cx, F - 7 + 1.2, 'emergency', { radius:150, strength:.6 });
      if (x1 - x0 >= 7) tube(cx + 1, F - 7, F);
    }
    this.emitter('steam', 921 * T, (F - 5) * T, { rate:.5 });
    this.emitter('sparks', 910 * T, (F - 3) * T);
    // warning at the level -2 shaft and at the mine gallery
    wp('biohazard_sign', g.shaftX + 1, g.shaftTop, 72);
    this.addProp('br_evac_mark', g.shaftX - 1, g.shaftTop - 1, { scale:1, behind:true, wall:true, offsetY:-36 });
    lamp(g.shaftX, g.shaftTop - 3.2, 'emergency', { radius:120, strength:.58 });
    this.addProp('warning_sign', 857, 153, { scale:.85, behind:true });
    this.addProp('br_sealed_door', 866, 153, { scale:.9, behind:true, alpha:.9 });
    this.s41Point(def, 2, 's41_console', 896, F - 1, { name:'Console de bloqueio BR-7' });
    this.s41Point(def, 3, 'alarm', 900, F - 1, { name:'Sirene de contenção', state:'off', area:def.name });
    this.s41Door(def, 4, 925, F - 1, { name:'Câmara tecnológica BR-7', tile:TL.DARK_METAL, locked:true, keyItem:'blackridge_keycard', forceTool:'crowbar', integrity:12, vault:true });
    this.s41Point(def, 5, 's41_note', 888, F - 1, { name:'Relatório BR-7', note:'br7_report' });
    entrances.push({ x:g.shaftX, y:g.shaftTop - 1 }, { x:855, y:153 });
    this.s41Spawn(spawns, 882, F, 'blackridge', 'stalker');
    this.s41Spawn(spawns, 887, F, 'blackridge', 'screamer');
    this.s41Spawn(spawns, 899, F, 'blackridge', 'armored');
    this.s41Spawn(spawns, 910, F, 'blackridge', 'armored');
    this.s41Spawn(spawns, 921, F, 'blackridge', 'contained');
    this.s41Spawn(spawns, 928, F, 'blackridge', 'contained');
    extra.landing = { x:g.tunnelX, y:F };
  }

  const yTop = (g.top ?? F - 6) - 1, yBottom = F + 1;
  const s = this.register(def.name, def.type, g.x0, g.x1 - g.x0, F, 'underground', {
    underground:true, y1:yTop, y2:yBottom, yTop, yBottom, riskTier:def.tier, expeditionId:def.id,
    stage41:true, content:def.tier >= 4 ? 'high' : 'medium', warning:def.warning,
    emergencyLights:['quarantine_camp', 'county_arsenal', 'blackridge_vault'].includes(def.id)
  });
  s.rooms = rooms;
  s.spawns = spawns;
  s.s41 = { id:def.id, tier:def.tier, entrances, hazards, sensors, landing:extra.landing, geo:g };
  this.world.undergroundZones.push({ name:def.name, kind:def.type, x1:g.x0, x2:g.x1, y1:yTop, y2:yBottom, riskTier:def.tier });
  return s;
};

// Field note inside the North County police station: the first link.
StructureManager.prototype.stage41Clues = function() {
  const police = this.structures.find(s => s.type === 'police');
  if (!police) return;
  const def = { id:'clues', slot:6 };
  const x = police.x + 11;
  this.s41Point(def, 1, 's41_note', x, police.groundY - 1, { name:'Bilhete do xerife', note:'police_note' });
  this.wallProp('corkboard', x, police.groundY, 58, { scale:.9 });
};

// Blackridge's level -2 is generated by LoreSystem after the structures; the
// BR-7 service shaft is re-cut through its floor slab afterwards.
StructureManager.prototype.stage41AfterBlackridge = function() {
  const def = STAGE41_EXPEDITIONS.find(d => d.id === 'blackridge_vault');
  const g = def && this.s41Geo?.[def.id];
  if (g) this.s41Shaft(g.shaftX, g.shaftTop, g.floor - 1, TILE.DARK_METAL);
};

StructureManager.prototype.makeHighRiskExpeditions = function() {
  for (const def of STAGE41_EXPEDITIONS) this.stage41BuildSite(def);
  this.stage41Clues();
};

// Re-carves the current geometry on a loaded world (saves older than the
// current layout). Door, shutter and hatch tiles are re-synced by the runtime.
StructureManager.prototype.restoreStage41Terrain = function() {
  for (const def of STAGE41_EXPEDITIONS) this.s41Carve(def);
};

// Cells that the Stage 41.0 build carved and the current layout no longer
// uses. The runtime restores them from the freshly generated world.
StructureManager.prototype.stage41LegacyCells = function() {
  const out = [];
  for (const L of STAGE41_LEGACY) {
    for (let x = L.x0 - 1; x <= L.x1 + 1; x++) for (let y = L.floor - 8; y <= L.floor; y++) out.push([x, y, false]);
    for (let y = 0; y <= L.floor - 1; y++) out.push([L.shaft, y, true]);
    if (L.tunnel) { const [a, b, y0, y1] = L.tunnel; for (let x = a; x <= b; x++) for (let y = y0; y <= y1; y++) out.push([x, y, false]); }
  }
  return out;
};

// Stage 41 content is generated after the Stage 20.1 interactive layer so the
// light switches, panels and alarms of older buildings are created exactly as
// in Stage 40 (their ids are what old saves restore).
const stage41RestoreInteractive = StructureManager.prototype.restoreInteractiveLayer;
StructureManager.prototype.restoreInteractiveLayer = function() {
  this.stage41LegacyPointSplit = this.nextPointId;
  stage41RestoreInteractive.call(this);
  this.makeHighRiskExpeditions();
};
