// Stage 41 static + generation validation. Runtime challenges, outposts and
// save migration (v40 and Stage 41.0) are exercised in tools/smoke.js.
const fs=require('fs');
const path=require('path');
const vm=require('vm');
const root=path.join(__dirname,'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
const src=read('js/stage41_expeditions.js');
const runtime=read('js/stage41_runtime.js');
const game=read('js/game.js');
const save=read('js/savegame.js');
const html=read('index.html');
const errors=[];
const names=['Abrigo do Xerife','Quarentena Estadual Harlow','Bunker Civil Greenwater','Arsenal Subterrâneo do Condado','Cofre Tecnológico Blackridge'];
for(const name of names)if(!src.includes(name))errors.push(`expedição ausente: ${name}`);
for(let tier=1;tier<=5;tier++)if(!src.includes(`tier:${tier}`))errors.push(`nível de risco ${tier} ausente`);
for(const id of ['pistol','shotgun','civilian_carbine','police_carbine','blackridge_carbine'])if(!src.includes(`'${id}'`))errors.push(`progressão de recompensa sem ${id}`);
if(!src.includes('restoreStage41Terrain'))errors.push('migração de terreno para saves antigos ausente');
if(!/version:41/.test(game)||!/40, 41/.test(save))errors.push('save v41 ou compatibilidade v40 ausente');
if(!html.includes('js/stage41_expeditions.js')||!html.includes('js/stage41_runtime.js'))errors.push('scripts Stage 41 não carregados no HTML');
if(html.indexOf('js/stage41_runtime.js')>html.indexOf('js/game.js'))errors.push('runtime Stage 41 carrega depois do game.js');
if(!html.includes('stage41-expeditions.css')||!html.includes('id="s41Banner"')||!html.includes('id="s41Note"'))errors.push('interface diegética Stage 41 ausente no HTML');
for(const hook of ['stage41:stage41.exportState()','stage41.importState(save.stage41, save)','stage41.restoreTerrain(save)','stage41.migratePointRows(save)','stage41.migrateContainers(save, generatedContainers)','stage41.drawMapMarker(','stage41.update(dt)'])
  if(!game.includes(hook))errors.push(`integração ausente no game.js: ${hook}`);
for(const kind of ['s41_note','s41_tripwire','s41_rest','s41_station','s41_panel','s41_console','s41_escape'])
  if(!src.includes(`'${kind}'`)||!runtime.includes(`'${kind}'`))errors.push(`desafio/ponto sem implementação: ${kind}`);

// Generation: boot the county for several seeds and check the authored sites.
function boot(seed){
  const ctx=vm.createContext({console,Math,Map,Set,Array,Object,JSON,Uint8Array,Int16Array,Float32Array,Uint8ClampedArray,Number,String,Boolean});
  for(const f of ['config.js','decor_data.js','world.js','structures.js','underground.js'])vm.runInContext(read('js/'+f),ctx,{filename:f});
  vm.runInContext('const AREA_PROFILES={};',ctx);
  for(const f of ['stage41_expeditions.js','lore.js'])vm.runInContext(read('js/'+f),ctx,{filename:f});
  vm.runInContext(`globalThis.__w=new World(${seed});globalThis.__s=new StructureManager(__w,${seed});globalThis.__l=new LoreSystem(__w,__s,{count:()=>0},null,${seed});`,ctx);
  return {world:ctx.__w,S:ctx.__s,lore:ctx.__l,TILE:vm.runInContext('TILE',ctx),TILE_INFO:vm.runInContext('TILE_INFO',ctx),CONFIG:vm.runInContext('CONFIG',ctx),DEFS:vm.runInContext('STAGE41_EXPEDITIONS',ctx),BASE:vm.runInContext('S41_POINT_BASE',ctx)};
}
let checked=0;
const seeds=[1000,8919,16838,24757,32676,40595,...Array.from({length:Number(process.env.S41_SEEDS||14)},(_,i)=>(i*2654435761+12345)%99999999)];
for(const seed of seeds){
  const {world,S,lore,TILE,TILE_INFO,CONFIG,DEFS,BASE}=boot(seed),T=CONFIG.TILE;
  if(CONFIG.WORLD_W!==1900||CONFIG.WORLD_H!==184)errors.push(`seed ${seed}: mapa fora de 1900×184`);
  const sites=S.structures.filter(s=>s.stage41);
  if(sites.length!==5)errors.push(`seed ${seed}: ${sites.length}/5 expedições`);
  // Stage 41 points never take ids from the older numbering.
  const ids=S.points.map(p=>p.id);
  if(new Set(ids).size!==ids.length)errors.push(`seed ${seed}: ids de pontos repetidos`);
  const legacy=S.points.filter(p=>!p.s41).map(p=>p.id).sort((a,b)=>a-b);
  if(legacy.some((id,i)=>id!==i+1))errors.push(`seed ${seed}: numeração antiga de pontos deixou de ser contínua`);
  if(S.points.some(p=>p.s41&&(p.id<BASE||p.id>=BASE+1000)))errors.push(`seed ${seed}: ponto Stage 41 fora da faixa 41xxx`);
  for(const s of sites){
    const def=DEFS.find(d=>d.id===s.expeditionId);
    if(!s.s41?.entrances?.length)errors.push(`seed ${seed}: ${s.name} sem entrada`);
    // Every surface entrance keeps standing room and is capped (no open hole).
    for(const e of s.s41.entrances){
      if(TILE_INFO[world.get(e.x,e.y)]?.solid||TILE_INFO[world.get(e.x,e.y-1)]?.solid)errors.push(`seed ${seed}: entrada de ${s.name} sem espaço em ${e.x},${e.y}`);
      const below=world.get(e.x,e.y+1);
      if(below!==TILE.CATWALK&&below!==TILE.METAL&&!TILE_INFO[below]?.solid)errors.push(`seed ${seed}: entrada de ${s.name} é um buraco aberto em ${e.x},${e.y+1}`);
    }
    // Escape or alternative route: a second entrance, a one-way hatch or two
    // internal routes (arsenal: service corridor and main hall).
    const routes=s.s41.entrances.length+(S.points.some(p=>p.s41===def.id&&p.kind==='s41_escape')?1:0)+(def.id==='county_arsenal'?1:0);
    if(routes<2)errors.push(`seed ${seed}: ${s.name} sem rota de fuga ou alternativa`);
    const boxes=S.containers.filter(c=>c.expeditionId===def.id);
    if(boxes.length!==Object.keys(def.boxes).length||boxes.some(c=>!c.stage41Key))errors.push(`seed ${seed}: containers de ${s.name} sem chave estável`);
    if(boxes.filter(c=>c.stage41Vault).length!==1)errors.push(`seed ${seed}: ${s.name} precisa de exatamente um cofre principal`);
    const vaultDoor=S.points.find(p=>p.s41===def.id&&p.vault);
    if(!vaultDoor)errors.push(`seed ${seed}: ${s.name} sem porta/obstáculo do cofre`);
    else if(vaultDoor.kind==='door'&&!vaultDoor.locked)errors.push(`seed ${seed}: ${vaultDoor.name} começa destrancada`);
    // The shell of every level is sealed: nothing leaks into natural caves
    // except the authored openings (ladders, caps, doors, the sheriff tunnel).
    const levels=new Map();
    for(const r of s.rooms){const L=levels.get(r.floorY)||{x0:r.x0,x1:r.x1,top:r.ceilY};L.x0=Math.min(L.x0,r.x0);L.x1=Math.max(L.x1,r.x1);levels.set(r.floorY,L);}
    for(const [floorY,L] of levels)for(let y=L.top+1;y<floorY;y++)for(const x of [L.x0-1,L.x1+1]){
      const t=world.get(x,y);
      if(TILE_INFO[t]?.solid||t===TILE.LADDER||t===TILE.CATWALK)continue;
      if(def.id==='sheriff_cache'&&x===L.x0-1&&y>=floorY-2)continue;
      errors.push(`seed ${seed}: casca de ${s.name} aberta em ${x},${y}`);
    }
  }
  // Every box can be reached from the site's own first entrance (doors count
  // as openable; the BR-7 routes after Stage 31 are covered by smoke.js).
  {
    const W=CONFIG.WORLD_W,H=CONFIG.WORLD_H,open=new Set();
    for(const p of S.points)if(['door','barricade','shutter'].includes(p.kind))for(let a=0;a<(p.width||1);a++)for(let b=0;b<(p.height||1);b++)open.add((p.tileY-b)*W+p.tileX+a);
    const solid=(x,y)=>x<0||x>=W||y<0||y>=H||(!open.has(y*W+x)&&Boolean(TILE_INFO[world.get(x,y)]?.solid));
    const ladder=(x,y)=>world.get(x,y)===TILE.LADDER,plat=(x,y)=>Boolean(TILE_INFO[world.get(x,y)]?.platform);
    const free=(x,y)=>!solid(x,y)&&!solid(x,y-1),sup=(x,y)=>solid(x,y+1)||plat(x,y+1)||ladder(x,y)||ladder(x,y+1);
    for(const s of sites){
      const e=s.s41.entrances[0],seen=new Uint8Array(W*H),q=[];
      const push=(x,y)=>{if(x<1||x>=W-1||y<2||y>=H-1)return;const k=y*W+x;if(seen[k]||!free(x,y))return;let yy=y;while(!sup(x,yy)&&yy<H-2&&free(x,yy+1))yy++;seen[k]=1;seen[yy*W+x]=1;q.push([x,yy]);};
      push(e.x,e.y);
      while(q.length){const [x,y]=q.pop();for(const dx of [-1,1]){push(x+dx,y);if(!solid(x,y-2))push(x+dx,y-1);}
        for(let h=1;h<=3;h++){if(solid(x,y-h-1))break;push(x,y-h);for(const dx of [-1,1]){if(!free(x+dx,y-h))continue;push(x+dx,y-h);push(x+dx*2,y-h);}}
        if(ladder(x,y)||ladder(x,y-1))push(x,y-1);if(ladder(x,y+1)||plat(x,y+1))push(x,y+1);}
      const reach=(cx,cy)=>{for(let y=cy-2;y<=cy+2;y++)for(let x=cx-2;x<=cx+2;x++)if(seen[y*W+x])return true;return false;};
      for(const c of S.containers.filter(c=>c.expeditionId===s.expeditionId))
        if(!reach(Math.floor((c.x+c.width/2)/T),Math.floor((c.y+c.height/2)/T)))errors.push(`seed ${seed}: ${c.name} inalcançável a partir da entrada de ${s.name}`);
    }
  }
  // Points must not steal the E key from containers or lore objects.
  for(const p of S.points.filter(p=>p.s41)){
    const px=(p.tileX+.5)*T,py=(p.tileY+.5)*T;
    for(const c of S.containers)if(Math.hypot(c.x+c.width/2-px,c.y+c.height/2-py)<3*T)errors.push(`seed ${seed}: ${p.name} encobre ${c.name}`);
    for(const o of lore.interactables)if(Math.hypot(o.x+o.w/2-px,o.y+o.h/2-py)<3*T)errors.push(`seed ${seed}: ${p.name} encobre ${o.name}`);
  }
  checked++;
}
if(errors.length){console.error([...new Set(errors)].join('\n'));process.exit(1);}
console.log(`STAGE41 OK — 5 expedições, riscos 1–5, loot progressivo, ids 41xxx estáveis, rotas de fuga, ${checked} seeds, save v41`);
